
public class MySecondDataStructure {
	/*
     * You may add any fields that you wish to add.
     * Remember that the use of built-in Java classes is not allowed,
     * the only variables types you can use are: 
     * 	-	the given classes in the assignment
     * 	-	basic arrays
     * 	-	primitive variables
     */
	
	/***
     * This function is the Init function.
	 * @param N The maximum number of elements in the data structure at each time.
     */
	public MySecondDataStructure(int N) {
		throw new UnsupportedOperationException("Delete this line and replace it with your implementation");
	}
	
	public void insert(Product product) {
		throw new UnsupportedOperationException("Delete this line and replace it with your implementation");
	}
	
	public void findAndRemove(int id) {
		throw new UnsupportedOperationException("Delete this line and replace it with your implementation");
	}
	
	public int medianQuality() {
		throw new UnsupportedOperationException("Delete this line and replace it with your implementation");
	}
	
	public double avgQuality() {
		throw new UnsupportedOperationException("Delete this line and replace it with your implementation");
	}

	public void raisePrice(int raise, int quality) {
		throw new UnsupportedOperationException("Delete this line and replace it with your implementation");
	}

	public Product mostExpensive() {
		throw new UnsupportedOperationException("Delete this line and replace it with your implementation");
	}

}
