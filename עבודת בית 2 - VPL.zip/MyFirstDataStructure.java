/**
 * @param <T> The type of the satellite data of the elements in the data structure.
 */
public class MyFirstDataStructure<T> {
	/*
     * You may add any fields that you wish to add.
     * Remember that the use of built-in Java classes is not allowed,
     * the only variables types you can use are:
     * 	-	the given classes in the assignment
     * 	-	basic arrays
     * 	-	primitive variables
     */

	/***
     * This function is the Init function.
	 * @param N The maximum number of elements in the data structure at each time.
     */
	public MyFirstDataStructure(int N) {
		throw new UnsupportedOperationException("Delete this line and replace it with your implementation");
	}
	
	public void insert(Element<T> x) {
		throw new UnsupportedOperationException("Delete this line and replace it with your implementation");
	}
	
	public void findAndRemove(int k) {
		throw new UnsupportedOperationException("Delete this line and replace it with your implementation");
	}

	public Element<T> maximum() {
		throw new UnsupportedOperationException("Delete this line and replace it with your implementation");
	}

	public Element<T> first() {
		throw new UnsupportedOperationException("Delete this line and replace it with your implementation");
	}

	public Element<T> last() {
		throw new UnsupportedOperationException("Delete this line and replace it with your implementation");
	}

}
